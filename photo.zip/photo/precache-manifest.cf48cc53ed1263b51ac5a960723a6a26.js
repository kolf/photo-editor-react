self.__precacheManifest = [
  {
    "revision": "a1165cf06c7d5191baf6a0492016da38",
    "url": "/photo/static/media/tk.a1165cf0.png"
  },
  {
    "revision": "d638a50b4ffccb937058",
    "url": "/photo/static/js/runtime~main.d638a50b.js"
  },
  {
    "revision": "3a41e1fe40f7c3163258",
    "url": "/photo/static/js/main.3a41e1fe.chunk.js"
  },
  {
    "revision": "87e435e3463393027cf3",
    "url": "/photo/static/js/1.87e435e3.chunk.js"
  },
  {
    "revision": "3a41e1fe40f7c3163258",
    "url": "/photo/static/css/main.cdec0e22.chunk.css"
  },
  {
    "revision": "e7b5a7227ef9ec120ea8b0967119dee5",
    "url": "/photo/index.html"
  }
];